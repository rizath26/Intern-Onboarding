# BookSwap: Day 3 Quality Attribute Plan

BookSwap is moving from one building to a 200-building trial, and a tabloid feature lands next Sunday. No code changes today. This repo is the evidence that the design can take it, plus an honest list of what would have to change where it can't.

## What's in here

```
bookswap-quality/
├── slo/slo-map.md                    NFR -> SLI -> SLO, error budget policy
├── reliability/runbook.md            SQL outage, Redis outage, Sunday 10x spike
├── security/review.md                7-category review + BOLA + PII + ZAP discussion
├── security/threats.csv              every finding, severity, owner
├── security/run-zap.sh               the baseline scan we ran against the Prism mock
├── security/zap-baseline-report.html (output of run-zap.sh)
├── observability/plan.md             logs / metrics / traces, dashboards, alert proposal
├── observability/alerts.yaml         alert definitions with queries and runbook links
└── README.md
```

## Assumptions we planned against

These come from our Day 2 design. If a number here doesn't match the Day 2 doc, the Day 2 doc wins and the affected thresholds should be recalculated.

| Area | Assumption |
|------|-----------|
| Scale | 200 buildings, ~120 active members each, ~24,000 members |
| Normal peak | ~20 RPS total at the API, ~12 RPS of that is `GET /books` search |
| Sunday spike | 10x normal for 4 hours: ~200 RPS total, ~120 RPS search |
| Compute | Azure App Service, Premium v3 (P1v3), 3 instances baseline, stateless API |
| Database | Azure SQL, General Purpose, 4 vCores |
| Cache | Azure Cache for Redis, Standard C1 (primary + replica) |
| Async | Azure Service Bus queue `email-digest` for the weekly digest emails |
| Files | Azure Blob Storage for book cover photos, uploaded via short-lived SAS |
| Edge | Azure Front Door (Standard/Premium) with WAF in front of App Service |
| Auth | BookSwap issues its own JWTs (RS256), signing key in Key Vault |
| Search | SQL query over title/author; results cached in Redis |

### Endpoints (from the Day 2 OpenAPI)

| Method | Path | Notes |
|--------|------|-------|
| GET | /health | only public endpoint |
| POST | /auth/login | returns access token |
| GET | /books?q=&sort=&page= | catalogue search |
| GET | /books/{bookId} | book detail |
| POST | /listings | create listing, takes `Idempotency-Key` header |
| GET / PATCH / DELETE | /listings/{listingId} | |
| POST | /loans | borrow request |
| GET | /loans/{loanId} | |
| POST | /loans/{loanId}/return | |
| GET | /members/{memberId} | profile incl. flat number |
| GET | /members/{memberId}/loans | loan history |

## Design changes this plan says we need

The plan is mostly configuration, but four things are real changes and should go on the Day 4 backlog:

1. Replace `/members/{memberId}/loans` with `/me/loans` and enforce ownership server-side (BOLA fix, see security review S-02).
2. Idempotency keys stored in SQL in the same transaction as the listing insert (runbook Failure 1).
3. Lock App Service so it only accepts traffic from our Front Door profile (security review S-05).
4. Search needs something better than `LIKE '%term%'` before the spike (see "Out of budget right now" in the SLO map).

## Finishing the submission

1. Run `security/run-zap.sh` with the Prism mock up on port 4010. It writes `zap-baseline-report.html` into `security/`.
2. Open the report and check the "ZAP baseline findings" section of `security/review.md` matches what your scan actually found.
3. Rename the flat files from `yourname-` to your name, then zip this folder.
